<?php

namespace Plugin\PointsOnReferral\Exception;

class DependencyNotFoundException extends \Exception {

}
