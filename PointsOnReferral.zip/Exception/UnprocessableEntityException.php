<?php

namespace Plugin\PointsOnReferral\Exception;

class UnprocessableEntityException extends \Exception {

}
